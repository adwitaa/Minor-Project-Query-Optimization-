package com.astronomyclub.db;

import org.bson.Document;
import java.util.*;

public class QueryCache {
    private static final Map<String, List<Document>> CACHE = new HashMap<>();

    public static List<Document> get(String key) {
        return CACHE.get(key);
    }

    public static void put(String key, List<Document> results) {
        CACHE.put(key, results);
    }

    public static boolean contains(String key) {
        return CACHE.containsKey(key);
    }

    public static void clear() {
        CACHE.clear();
    }
}
