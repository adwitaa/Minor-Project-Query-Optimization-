package com.myapp.db;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class MongoDBUtil {

    // ✅ Single MongoClient instance (thread-safe)
    private static final MongoClient mongoClient;

    static {
        // Connect to MongoDB server on localhost:27017
        mongoClient = MongoClients.create("mongodb://localhost:27017");
    }

    /**
     * Get a MongoDatabase instance by name
     * @param dbName the database name
     * @return MongoDatabase object
     */
    public static MongoDatabase getDatabase(String dbName) {
        return mongoClient.getDatabase(dbName);
    }

    /**
     * Close the MongoClient (optional, e.g. on app shutdown)
     */
    public static void close() {
        mongoClient.close();
    }
}
