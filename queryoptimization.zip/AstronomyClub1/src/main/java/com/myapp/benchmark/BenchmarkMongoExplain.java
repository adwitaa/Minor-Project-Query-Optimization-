package com.myapp.benchmark;

import com.mongodb.client.*;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;

public class BenchmarkMongoExplain {
    public static void main(String[] args) {
        // Connect to MongoDB
        try (MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017")) {

            MongoDatabase database = mongoClient.getDatabase("astronomyClubDb"); // your DB
            MongoCollection<Document> collection = database.getCollection("members");

            // -------------------------
            // Clean collection for fair test
            // -------------------------
            collection.drop();

            // -------------------------
            // Insert dummy data
            // -------------------------
            List<Document> docs = new ArrayList<>();
            int totalDocs = 1_000_000;
            for (int i = 0; i < totalDocs; i++) {
                docs.add(new Document("name", "User" + i)
                        .append("email", "user" + i + "@example.com")
                        .append("password", "pass" + i)
                        .append("course", "Course" + (i % 10))); // 10 different courses
            }
            collection.insertMany(docs);
            System.out.println("Inserted " + totalDocs + " dummy documents.\n");

            // -------------------------
            // Query benchmark
            // -------------------------
            String emailToFind = "user500000@example.com"; // test email
            Document query = new Document("email", emailToFind);

            // --- BEFORE INDEX ---
            System.out.println("--- Query BEFORE Index ---");
            long startBefore = System.nanoTime();
            Document resultBefore = collection.find(query).first();
            long endBefore = System.nanoTime();
            System.out.println("Result: " + resultBefore);
            long timeBeforeNs = endBefore - startBefore;
            System.out.println("Execution time (ms): " + (timeBeforeNs / 1_000_000));

            // Explain plan before index
            Document explainBefore = database.runCommand(
                    new Document("explain",
                            new Document("find", collection.getNamespace().getCollectionName())
                                    .append("filter", query))
                            .append("verbosity", "executionStats")
            );
            System.out.println("Winning stage BEFORE index: " + extractWinningStage(explainBefore));

            // --- CREATE INDEX ---
            System.out.println("\nCreating index on 'email'...");
            collection.createIndex(new Document("email", 1));

            // --- AFTER INDEX ---
            System.out.println("\n--- Query AFTER Index ---");
            long startAfter = System.nanoTime();
            Document resultAfter = collection.find(query).first();
            long endAfter = System.nanoTime();
            System.out.println("Result: " + resultAfter);
            long timeAfterNs = endAfter - startAfter;
            System.out.println("Execution time (ms): " + (timeAfterNs / 1_000_000));

            // Explain plan after index
            Document explainAfter = database.runCommand(
                    new Document("explain",
                            new Document("find", collection.getNamespace().getCollectionName())
                                    .append("filter", query))
                            .append("verbosity", "executionStats")
            );
            System.out.println("Winning stage AFTER index: " + extractWinningStage(explainAfter));

            // -------------------------
            // Calculate and print improvement
            // -------------------------
            double improvement = ((double)(timeBeforeNs - timeAfterNs) / timeBeforeNs) * 100;
            System.out.println("\nQuery execution improvement: " + String.format("%.2f", improvement) + "%");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ---------------- Helper methods ----------------
    private static String extractWinningStage(Document explainDoc) {
        try {
            Document qp = explainDoc.get("queryPlanner", Document.class);
            Document winning = qp.get("winningPlan", Document.class);
            return drillStage(winning);
        } catch (Exception e) {
            return "UNKNOWN";
        }
    }

    private static String drillStage(Document plan) {
        if (plan == null) return "UNKNOWN";
        String stage = plan.getString("stage");
        if (stage != null) return stage;
        Document input = plan.get("inputStage", Document.class);
        return input != null ? drillStage(input) : "UNKNOWN";
    }
}
