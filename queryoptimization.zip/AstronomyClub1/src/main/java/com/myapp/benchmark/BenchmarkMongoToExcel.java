package com.myapp.benchmark;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.myapp.db.MongoDBUtil;
import org.bson.Document;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.File;   // <--- added import
import java.util.ArrayList;
import java.util.List;

public class BenchmarkMongoToExcel {

    public static void main(String[] args) {
        try {
            MongoDatabase database = MongoDBUtil.getDatabase("astronomyClubDb");
            MongoCollection<Document> collection = database.getCollection("members");

            // ----------------------------
            // Define multiple queries
            // ----------------------------
            List<Document> queries = new ArrayList<>();
            queries.add(new Document("email", "user500000@example.com"));
            queries.add(new Document("course", "Course1"));
            queries.add(new Document("name", "User123").append("course", "Course3"));

            // ----------------------------
            // Drop indexes for BEFORE benchmark
            // ----------------------------
            collection.dropIndexes();

            // ----------------------------
            // Create Excel workbook
            // ----------------------------
            Workbook workbook = new XSSFWorkbook();
            Sheet sheet = workbook.createSheet("Query Benchmark");

            // Header row
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("Query");
            header.createCell(1).setCellValue("Execution Time Before (ms)");
            header.createCell(2).setCellValue("Execution Time After (ms)");
            header.createCell(3).setCellValue("Improvement (%)");

            int rowIndex = 1;

            // ----------------------------
            // Measure BEFORE index
            // ----------------------------
            List<Long> timesBefore = new ArrayList<>();
            for (Document query : queries) {
                long start = System.nanoTime();
                collection.find(query).first();
                long end = System.nanoTime();
                long timeMs = (end - start) / 1_000_000;
                timesBefore.add(timeMs);
            }

            // ----------------------------
            // Create indexes
            // ----------------------------
            collection.createIndex(new Document("email", 1));
            collection.createIndex(new Document("course", 1));
            collection.createIndex(new Document("name", 1).append("course", 1));

            // ----------------------------
            // Measure AFTER index
            // ----------------------------
            List<Long> timesAfter = new ArrayList<>();
            for (Document query : queries) {
                long start = System.nanoTime();
                collection.find(query).first();
                long end = System.nanoTime();
                long timeMs = (end - start) / 1_000_000;
                timesAfter.add(timeMs);
            }

            // ----------------------------
            // Write results to Excel
            // ----------------------------
            for (int i = 0; i < queries.size(); i++) {
                Document query = queries.get(i);
                long timeBefore = timesBefore.get(i);
                long timeAfter = timesAfter.get(i);
                double improvement = ((double)(timeBefore - timeAfter) / timeBefore) * 100;

                Row row = sheet.createRow(rowIndex++);
                row.createCell(0).setCellValue(query.toJson());
                row.createCell(1).setCellValue(timeBefore);
                row.createCell(2).setCellValue(timeAfter);
                row.createCell(3).setCellValue(String.format("%.2f", improvement));
            }

            // Autosize columns
            for (int i = 0; i < 4; i++) {
                sheet.autoSizeColumn(i);
            }

            // Save Excel
            String fileName = "MongoQueryBenchmark_Real.xlsx";
            FileOutputStream fos = new FileOutputStream(fileName);
            workbook.write(fos);
            workbook.close();
            fos.close();

            System.out.println("Real benchmark saved to Excel: " + fileName);

            // ----------------------------
            // Print absolute path
            // ----------------------------
            File file = new File(fileName);
            System.out.println("Excel saved at: " + file.getAbsolutePath());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
