package com.myapp.optimization;

import org.bson.Document;

import java.util.List;

/**
 * Simple QueryRouter to pick between standard, optimized, and cached queries.
 */
public class QueryRouter {

    public static List<Document> execute(String mode, String dbName, String collectionName) {
        switch (mode.toLowerCase()) {
            case "standard":
                return QueryOptimizer.standardQuery(dbName, collectionName);
            case "optimized":
                // example: fetch only common fields 'name','email','role'
                return QueryOptimizer.optimizedProjectionQuery(dbName, collectionName, "name", "email", "role");
            case "cached":
                return QueryOptimizer.cachedQuery(dbName, collectionName, "cached_" + collectionName, "name", "email", "role");
            case "adaptive":
                return QueryOptimizer.adaptiveQuery(dbName, collectionName, "cached_" + collectionName, "name", "email", "role");
            default:
                return QueryOptimizer.standardQuery(dbName, collectionName);
        }
    }
}
