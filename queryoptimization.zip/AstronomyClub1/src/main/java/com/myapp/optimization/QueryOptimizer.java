package com.myapp.optimization;

import com.myapp.db.MongoDBUtil;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.FindIterable;
import com.mongodb.client.model.Projections;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.util.ArrayList;
import java.util.List;

/**
 * QueryOptimizer provides projection-based and cached query helpers.
 * It expects an existing MongoDBUtil class with a getDatabase(String) method.
 */
public class QueryOptimizer {

    private static double lastLatencyMs = 0.0;
    private static final double LATENCY_THRESHOLD_MS = 100.0;

    public static List<Document> standardQuery(String dbName, String collectionName) {
        MongoCollection<Document> col = MongoDBUtil.getDatabase(dbName).getCollection(collectionName);
        List<Document> out = new ArrayList<>();
        FindIterable<Document> it = col.find();
        it.into(out);
        return out;
    }

    public static List<Document> optimizedProjectionQuery(String dbName, String collectionName, String... fields) {
        MongoCollection<Document> col = MongoDBUtil.getDatabase(dbName).getCollection(collectionName);
        Bson projection = Projections.include(fields);
        long t0 = System.nanoTime();
        List<Document> out = new ArrayList<>();
        FindIterable<Document> it = col.find().projection(projection);
        it.into(out);
        long t1 = System.nanoTime();
        lastLatencyMs = (t1 - t0) / 1e6;
        return out;
    }

    public static List<Document> cachedQuery(String dbName, String collectionName, String cacheKey, String... fields) {
        if (CacheManager.contains(cacheKey)) {
            return CacheManager.get(cacheKey);
        }
        List<Document> res = optimizedProjectionQuery(dbName, collectionName, fields);
        CacheManager.put(cacheKey, res);
        return res;
    }

    public static List<Document> adaptiveQuery(String dbName, String collectionName, String cacheKey, String... fields) {
        if (lastLatencyMs > LATENCY_THRESHOLD_MS && CacheManager.contains(cacheKey)) {
            System.out.println("[QueryOptimizer] Using cached strategy due to high latency: " + lastLatencyMs + " ms");
            return CacheManager.get(cacheKey);
        } else if (lastLatencyMs > LATENCY_THRESHOLD_MS) {
            System.out.println("[QueryOptimizer] Using cached strategy and populating cache (latency: " + lastLatencyMs + " ms)");
            return cachedQuery(dbName, collectionName, cacheKey, fields);
        } else {
            System.out.println("[QueryOptimizer] Using optimized projection strategy (latency: " + lastLatencyMs + " ms)");
            return optimizedProjectionQuery(dbName, collectionName, fields);
        }
    }
}
