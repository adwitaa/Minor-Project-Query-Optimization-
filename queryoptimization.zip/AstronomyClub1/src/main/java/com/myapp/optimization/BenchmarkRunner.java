package com.myapp.optimization;

import com.myapp.db.MongoDBUtil;
import com.myapp.optimization.CacheManager;
import com.myapp.optimization.QueryRouter;
import org.bson.Document;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.Instant;
import java.util.List;

/**
 * BenchmarkRunner runs different query modes and records latencies to a CSV file.
 * It assumes MongoDB is running locally and a database/collection are available.
 */
public class BenchmarkRunner {

    public static void main(String[] args) {
        String dbName = "AstronomyClub1";
        String collectionName = "users"; // change if your main collection is different
        String outCsv = "results/benchmark_results.csv";
        try (PrintWriter pw = new PrintWriter(new FileWriter(outCsv, false))) {
            pw.println("mode,latency_ms,timestamp,cache_size");
            // Warmup: standard
            System.out.println("Warming up standard query...");
            long start = System.nanoTime();
            QueryRouter.execute("standard", dbName, collectionName);
            long end = System.nanoTime();
            double latency = (end - start) / 1e6;
            pw.printf("%s,%.3f,%s,%d\n", "standard", latency, Instant.now().toString(), CacheManager.size());
            System.out.println("Standard latency: " + latency + " ms");

            // Optimized projection
            System.out.println("Running optimized projection query...");
            start = System.nanoTime();
            QueryRouter.execute("optimized", dbName, collectionName);
            end = System.nanoTime();
            latency = (end - start) / 1e6;
            pw.printf("%s,%.3f,%s,%d\n", "optimized", latency, Instant.now().toString(), CacheManager.size());
            System.out.println("Optimized latency: " + latency + " ms");

            // Cached
            System.out.println("Running cached query...");
            start = System.nanoTime();
            QueryRouter.execute("cached", dbName, collectionName);
            end = System.nanoTime();
            latency = (end - start) / 1e6;
            pw.printf("%s,%.3f,%s,%d\n", "cached", latency, Instant.now().toString(), CacheManager.size());
            System.out.println("Cached latency: " + latency + " ms");

            // Adaptive
            System.out.println("Running adaptive query...");
            start = System.nanoTime();
            QueryRouter.execute("adaptive", dbName, collectionName);
            end = System.nanoTime();
            latency = (end - start) / 1e6;
            pw.printf("%s,%.3f,%s,%d\n", "adaptive", latency, Instant.now().toString(), CacheManager.size());
            System.out.println("Adaptive latency: " + latency + " ms");

            pw.flush();
            System.out.println("Benchmark results saved to " + outCsv);
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Failed to write benchmark CSV: " + e.getMessage());
        }
    }
}
