package com.myapp.optimization;

import java.util.concurrent.ConcurrentHashMap;
import java.util.List;
import org.bson.Document;

/**
 * Simple in-memory cache manager using ConcurrentHashMap.
 */
public class CacheManager {
    private static final ConcurrentHashMap<String, java.util.List<Document>> cache = new ConcurrentHashMap<>();

    public static java.util.List<Document> get(String key) {
        return cache.get(key);
    }

    public static void put(String key, java.util.List<Document> value) {
        cache.put(key, value);
    }

    public static boolean contains(String key) {
        return cache.containsKey(key);
    }

    public static void clear() {
        cache.clear();
    }

    public static int size() {
        return cache.size();
    }
}
