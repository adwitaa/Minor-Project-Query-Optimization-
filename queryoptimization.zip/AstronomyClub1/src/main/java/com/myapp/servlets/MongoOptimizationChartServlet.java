package com.myapp.servlets;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.OutputStream;

@WebServlet("/chart")
public class MongoOptimizationChartServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try (MongoClient client = MongoClients.create("mongodb://localhost:27017")) {
            MongoDatabase db = client.getDatabase("astronomyClubDb");
            MongoCollection<Document> members = db.getCollection("members");

            // Example queries (before indexing)
            long timeByCourseNoIndex = getQueryTime(db, members, new Document("course", "Astronomy"));
            long timeByEmailNoIndex = getQueryTime(db, members, new Document("email", "test@example.com"));

            // Add indexes for optimization
            members.createIndex(new Document("course", 1));
            members.createIndex(new Document("email", 1));

            // Run queries again (after indexing)
            long timeByCourseWithIndex = getQueryTime(db, members, new Document("course", "Astronomy"));
            long timeByEmailWithIndex = getQueryTime(db, members, new Document("email", "test@example.com"));

            // Populate dataset
            dataset.addValue(adjust(timeByCourseNoIndex), "Before Optimization", "Find by course");
            dataset.addValue(adjust(timeByCourseWithIndex), "After Optimization", "Find by course");

            dataset.addValue(adjust(timeByEmailNoIndex), "Before Optimization", "Find by email");
            dataset.addValue(adjust(timeByEmailWithIndex), "After Optimization", "Find by email");

        } catch (Exception e) {
            e.printStackTrace();
        }

        // Create chart
        JFreeChart barChart = ChartFactory.createBarChart(
                "MongoDB Query Optimization (Before vs After)",
                "Query",
                "Execution Time (ms)",
                dataset,
                PlotOrientation.VERTICAL,
                true, true, false);

        // Set content type
        response.setContentType("image/png");

        // Write chart to servlet output stream
        try (OutputStream out = response.getOutputStream()) {
            ChartUtils.writeChartAsPNG(out, barChart, 900, 600);
        }
    }

    // Adjust negative values (errors) to 0 for chart readability
    private static long adjust(long v) {
        return v < 0 ? 0 : v;
    }

    /**
     * Run an explain command to get execution time
     */
    private static long getQueryTime(MongoDatabase db, MongoCollection<Document> collection, Document filter) {
        try {
            String collName = collection.getNamespace().getCollectionName();

            Document findDoc = new Document("find", collName).append("filter", filter);
            Document explainCommand = new Document("explain", findDoc)
                    .append("verbosity", "executionStats");

            Document explain = db.runCommand(explainCommand);

            if (explain != null && explain.containsKey("executionStats")) {
                Object v = ((Document) explain.get("executionStats")).get("executionTimeMillis");
                if (v instanceof Number) {
                    return ((Number) v).longValue();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1L;
    }
}
