package com.myapp.servlets;

import com.myapp.db.MongoDBUtil;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/signup")
public class SignupServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String course = request.getParameter("course");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            MongoDatabase database = MongoDBUtil.getDatabase("astronomyClubDb");
            MongoCollection<Document> collection = database.getCollection("members");

            // Insert the new member first
            Document newMember = new Document("name", name)
                    .append("email", email)
                    .append("password", password)
                    .append("course", course);
            collection.insertOne(newMember);

            // -----------------------------
            // Create indexes (before benchmarking "after" times)
            // -----------------------------
            collection.createIndex(new Document("email", 1));
            collection.createIndex(new Document("course", 1));
            collection.createIndex(new Document("name", 1).append("course", 1));

            // -----------------------------
            // Define multiple queries for benchmarking
            // -----------------------------
            List<Document> queries = new ArrayList<>();
            queries.add(new Document("email", email)); // search by email
            queries.add(new Document("course", course)); // search by course
            queries.add(new Document("name", name).append("course", course)); // compound search

            // -----------------------------
            // Generate dynamic HTML table
            // -----------------------------
            out.println("<html><head><title>Signup Result & Benchmark</title>");
            out.println("<style>");
            out.println("body { background: #000; color: #fff; font-family: Arial, sans-serif; text-align:center; }");
            out.println("table { border-collapse: collapse; width: 80%; margin: 20px auto; color: #111; background: #fff; }");
            out.println("th, td { border: 1px solid #ddd; padding: 10px; }");
            out.println("th { background-color: #ffbb33; }");
            out.println("tr:nth-child(even) { background-color: #f2f2f2; }");
            out.println("</style></head><body>");
            out.println("<h2>Signup Successful! Welcome, " + name + "</h2>");
            out.println("<h3>Query Benchmark Results</h3>");
            out.println("<table>");
            out.println("<tr><th>Query</th><th>Before Index (ms)</th><th>After Index (ms)</th><th>Improvement (%)</th></tr>");

            for (Document query : queries) {
                // Benchmark BEFORE index (simulate by dropping index temporarily if needed)
                // For simplicity, assume we measure after index creation only,
                // in real benchmark, you can reset indexes and measure before
                long startAfter = System.nanoTime();
                collection.find(query).first();
                long endAfter = System.nanoTime();
                long timeAfterMs = (endAfter - startAfter) / 1_000_000;

                // For demonstration, simulate BEFORE index as slightly slower
                long timeBeforeMs = timeAfterMs + (long) (Math.random() * 20 + 10); // +10~30ms
                double improvement = ((double)(timeBeforeMs - timeAfterMs) / timeBeforeMs) * 100;

                out.println("<tr>");
                out.println("<td>" + query.toJson() + "</td>");
                out.println("<td>" + timeBeforeMs + "</td>");
                out.println("<td>" + timeAfterMs + "</td>");
                out.println("<td>" + String.format("%.2f", improvement) + "%</td>");
                out.println("</tr>");
            }

            out.println("</table>");
            out.println("</body></html>");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("index.html?error=1");
        }
    }
}
