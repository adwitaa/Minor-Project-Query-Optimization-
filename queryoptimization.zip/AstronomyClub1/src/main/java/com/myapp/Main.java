package com.myapp;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.myapp.db.MongoDBUtil;
import org.bson.Document;

public class Main {
    public static void main(String[] args) {
        // Get DB connection
        MongoDatabase db = MongoDBUtil.getDatabase("AstronomyClub1");
        System.out.println("Database Name: " + db.getName());

        // Get the "users" collection
        MongoCollection<Document> users = db.getCollection("users");

        // Insert a new user
        Document newUser = new Document("name", "Bob")
                .append("age", 25)
                .append("role", "developer");
        users.insertOne(newUser);
        System.out.println("✅ Inserted new user: " + newUser.toJson());

        // Retrieve all users
        System.out.println("\n📋 Users in collection:");
        try (MongoCursor<Document> cursor = users.find().iterator()) {
            while (cursor.hasNext()) {
                System.out.println(cursor.next().toJson());
            }
        }
    }
}
